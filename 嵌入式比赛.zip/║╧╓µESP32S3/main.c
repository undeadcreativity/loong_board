#include <stdio.h>
#include "esp_system.h"
#include "esp_spi_flash.h"
#include "esp_wifi.h"
#include "esp_event.h"
#include "esp_log.h"
#include "esp_err.h"
#include "nvs_flash.h"
#include <string.h>
#include <sys/socket.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/event_groups.h"


#define WIFI_AP_SSID		"ESP_Center"			// WIFI 网络名称
#define WIFI_AP_PAS			"12345678"			    // WIFI 密码
#define WIFI_AP_MAXCON		4				    // 最大站连接数		最多只能被4个station同时连接
#define WIFI_AP_AUTH		WIFI_AUTH_WPA_WPA2_PSK

void app_main(void)
{

void app_main()
{
	ESP_LOGI(TAG, "APP Start......");
 
	ESP_ERROR_CHECK( nvs_flash_init() );
	tcpip_adapter_init();
	ESP_ERROR_CHECK(esp_event_loop_init(event_handler, NULL));	// 创建默认事件循环
	wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT();
	ESP_ERROR_CHECK(esp_wifi_init(&cfg));						// 使用默认wifi初始化配置
	wifi_config_t wifi_config = {								// 配置AP参数
		.ap = {
			.ssid = WIFI_AP_SSID,
			.ssid_len = 0,
			.max_connection = WIFI_AP_MAXCON,		
			.password = WIFI_AP_PAS,
			.authmode = WIFI_AP_AUTH,
		},
	};
	ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_AP));			// 设置工作模式为AP模式
	ESP_ERROR_CHECK(esp_wifi_set_config(ESP_IF_WIFI_AP, &wifi_config));// 设置AP配置
	ESP_ERROR_CHECK(esp_wifi_start());	
    						// 开启WIFI
     wifi_init_softap();
	//新建一个tcp连接任务
	xTaskCreate(&tcp_connect, "tcp_connect", 4096, NULL, 5, NULL);



}

// 建立TCP连接并从TCP接收数据
static void tcp_connect(void *pvParameters)
{
	while (1){
		g_rxtx_need_restart = false;
		// 等待WIFI连接信号量，死等
		xEventGroupWaitBits(tcp_event_group, WIFI_CONNECTED_BIT, false, true, portMAX_DELAY);
		ESP_LOGI(TAG, "start tcp connected");
		TaskHandle_t tx_rx_task = NULL;
		vTaskDelay(3000 / portTICK_RATE_MS);
		ESP_LOGI(TAG, "create tcp server");
		int socket_ret = create_tcp_server(true);// 建立server
		if (socket_ret == ESP_FAIL){// 建立失败
			ESP_LOGI(TAG, "create tcp socket error,stop...");
			continue;
		}else{// 建立成功
			ESP_LOGI(TAG, "create tcp socket succeed...");
			// 建立tcp接收数据任务
			if (pdPASS != xTaskCreate(&recv_data, "recv_data", 4096, NULL, 4, &tx_rx_task)){
				ESP_LOGI(TAG, "Recv task create fail!");
			}else{
				ESP_LOGI(TAG, "Recv task create succeed!");
			}
		}
		while (1){
			vTaskDelay(3000 / portTICK_RATE_MS);
			if (g_rxtx_need_restart){// 重新建立server，流程和上面一样
				ESP_LOGI(TAG, "tcp server error,some client leave,restart...");
				// 建立server
				if (ESP_FAIL != create_tcp_server(false)){
					if (pdPASS != xTaskCreate(&recv_data, "recv_data", 4096, NULL, 4, &tx_rx_task)){
						ESP_LOGE(TAG, "tcp server Recv task create fail!");
					}else{
						ESP_LOGI(TAG, "tcp server Recv task create succeed!");
						g_rxtx_need_restart = false;//重新建立完成，清除标记
					}
				}
			}
		}
	}
	vTaskDelete(NULL);
}

// 接收数据任务
void recv_data(void *pvParameters)
{
	int len = 0;
	char databuff[1024];
	while (1){
		memset(databuff, 0x00, sizeof(databuff));//清空缓存
		len = recv(connect_socket, databuff, sizeof(databuff), 0);//读取接收数据
		g_rxtx_need_restart = false;
		if (len > 0){
			ESP_LOGI(TAG, "recvData: %s", databuff);//打印接收到的数组
			send(connect_socket, databuff, strlen(databuff), 0);//接收数据回发
		}else{
			show_socket_error_reason("recv_data", connect_socket);//打印错误信息
			g_rxtx_need_restart = true;//服务器故障，标记重连
			vTaskDelete(NULL);
		}
	}
	close_socket();
	g_rxtx_need_restart = true;//标记重连
	vTaskDelete(NULL);
}

// wifi 事件
static esp_err_t event_handler(void *ctx, system_event_t *event)
{
	switch (event->event_id){
	case SYSTEM_EVENT_AP_STACONNECTED:  //AP模式-有STA连接成功
		// 作为ap，有sta连接
		ESP_LOGI(TAG, "station:" MACSTR " join,AID=%d\n",MAC2STR(event->event_info.sta_connected.mac),event->event_info.sta_connected.aid);
		xEventGroupSetBits(tcp_event_group, WIFI_CONNECTED_BIT);
		break;
	case SYSTEM_EVENT_AP_STADISCONNECTED://AP模式-有STA断线
		ESP_LOGI(TAG, "station:" MACSTR "leave,AID=%d\n",MAC2STR(event->event_info.sta_disconnected.mac),event->event_info.sta_disconnected.aid);
		//重新建立server
		g_rxtx_need_restart = true;
		xEventGroupClearBits(tcp_event_group, WIFI_CONNECTED_BIT);
		break;
	default:
		break;
	}
	return ESP_OK;
}